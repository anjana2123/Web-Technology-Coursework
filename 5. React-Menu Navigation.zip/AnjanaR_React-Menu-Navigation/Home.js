import React from 'react';
import './Home.css';

function Home() {
  return (
    <div className="home-container">
      <div className="welcome-section">
        <h2>Welcome to Axis Bank</h2>
        <p>Your trusted partner for all your banking and financial needs.</p>
      </div>

      <div className="features-section">
        <h3>Discover Our Services</h3>
        <div className="feature">
          <h4>Banking Solutions</h4>
          <p>Explore a range of banking products including savings accounts, personal loans, and credit cards.</p>
        </div>
        <div className="feature">
          <h4>Investment Opportunities</h4>
          <p>Maximize your wealth with our investment options, from fixed deposits to mutual funds.</p>
        </div>
        <div className="feature">
          <h4>Financial Planning</h4>
          <p>Plan for your future with our expert financial advisors who can help you achieve your goals.</p>
        </div>
      </div>

      <div className="commitment-section">
        <h3>Our Commitment</h3>
        <p>At Axis Bank, we are committed to delivering exceptional customer experiences and innovative solutions.</p>
        <p>With a focus on security, convenience, and personalized service, we're here to make banking effortless for you.</p>
      </div>

      <div className="get-started-section">
        <h3>Get Started Today</h3>
        <p>Whether you're new to banking or looking to switch, we're here to guide you on your financial journey.</p>
        <p>Explore our website, visit a branch near you, or reach out to our customer support team to get started.</p>
      </div>
    </div>
  );
}

export default Home;
