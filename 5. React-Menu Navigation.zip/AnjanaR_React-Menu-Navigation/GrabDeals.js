// GrabDeals.js
import React from 'react';
import './GrabDeals.css'; // Import the CSS file for this component

function GrabDeals() {
  return (
    <div className="grab-deals">
      <h2>Grab Deals</h2>
      <p>Explore our latest offers and promotions to make the most of your banking experience.</p>
      
      <div className="deal">
        <h3>Cashback Bonanza</h3>
        <p>Get up to 10% cashback on your credit card purchases for a limited time.</p>
        <p>Terms and Conditions:</p>
        <ul>
          <li>Valid for purchases made between [start date] and [end date]</li>
          <li>Maximum cashback amount per transaction is [amount]</li>
          <li>Applicable only on select credit cards</li>
        </ul>
        <button className="deal-button">Learn More</button>
      </div>
      
      <div className="deal">
        <h3>Home Loan Special</h3>
        <p>Avail of special interest rates and waived processing fees when you apply for a home loan this season.</p>
        <p>Terms and Conditions:</p>
        <ul>
          <li>Valid for new home loan applications submitted by [date]</li>
          <li>Applicable to loans with a minimum amount of [amount]</li>
          <li>Processing fee waiver subject to credit approval</li>
        </ul>
        <button className="deal-button">Apply Now</button>
      </div>
      
      <div className="deal">
        <h3>Travel Card Promotion</h3>
        <p>Get a complimentary travel card loaded with [amount] when you book an international holiday package.</p>
        <p>Terms and Conditions:</p>
        <ul>
          <li>Offer valid on select holiday packages</li>
          <li>Travel card will be issued upon booking confirmation</li>
          <li>[amount] will be pre-loaded on the card and can be used for travel expenses</li>
        </ul>
        <button className="deal-button">Book Now</button>
      </div>
      
      {/* Add more deal sections as needed */}
    </div>
  );
}

export default GrabDeals;
