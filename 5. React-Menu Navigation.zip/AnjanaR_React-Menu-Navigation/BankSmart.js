// BankSmart.js
import React from 'react';
import './BankSmart.css'; // Import the CSS file for this component

function BankSmart() {
  return (
    <div className="bank-smart">
      <h2>Bank Smart</h2>
      <p>Unlock a world of smart banking solutions designed to make managing your finances easier.</p>
      
      <div className="smart-feature">
        <h3>Axis Mobile Banking</h3>
        <p>Experience hassle-free banking on the go with our feature-rich mobile banking app.</p>
        <p>Features:</p>
        <ul>
          <li>View account statements and transaction history</li>
          <li>Transfer funds between accounts</li>
          <li>Pay bills and make mobile recharges</li>
        </ul>
        <button className="smart-button">Download App</button>
      </div>
      
      <div className="smart-feature">
        <h3>Net Banking</h3>
        <p>Manage your accounts, pay bills, and perform transactions online through our secure net banking platform.</p>
        <p>Features:</p>
        <ul>
          <li>Monitor account balances and transaction history</li>
          <li>Set up standing instructions for regular payments</li>
          <li>Access e-statements and tax-related documents</li>
        </ul>
        <button className="smart-button">Login</button>
      </div>
      
      <div className="smart-feature">
        <h3>Personalized Alerts</h3>
        <p>Stay informed about your account activity with custom alerts and notifications.</p>
        <p>Alert Types:</p>
        <ul>
          <li>Balance alerts</li>
          <li>Transaction alerts</li>
          <li>Payment due date reminders</li>
        </ul>
        <button className="smart-button">Set Up Alerts</button>
      </div>
      
      {/* Add more smart features as needed */}
    </div>
  );
}

export default BankSmart;
