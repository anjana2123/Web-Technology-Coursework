// ExploreProducts.js
import React from 'react';
import './ExploreProducts.css'; // Import the CSS file for this component

function ExploreProducts() {
  return (
    <div className="explore-products">
      <h2>Explore Products</h2>
      <p>Discover a wide range of banking and financial products tailored to your needs.</p>
      
      <div className="product">
        <h3>Personal Loans</h3>
        <p>Get the funds you need for life's important moments, whether it's a vacation, wedding, or home renovation.</p>
        <p>Features:</p>
        <ul>
          <li>Competitive interest rates</li>
          <li>Flexible repayment options</li>
          <li>No collateral required</li>
        </ul>
        <button className="product-button">Apply Now</button>
      </div>
      
      <div className="product">
        <h3>Savings Accounts</h3>
        <p>Start saving with our variety of flexible and rewarding accounts designed to help you achieve your financial goals.</p>
        <p>Features:</p>
        <ul>
          <li>High interest rates</li>
          <li>No minimum balance requirement</li>
          <li>ATM access and online banking</li>
        </ul>
        <button className="product-button">Learn More</button>
      </div>
      
      <div className="product">
        <h3>Credit Cards</h3>
        <p>Choose from a selection of credit cards with great rewards and benefits tailored to your spending habits.</p>
        <p>Features:</p>
        <ul>
          <li>Cashback on every purchase</li>
          <li>Travel rewards and airline miles</li>
          <li>24/7 customer support</li>
        </ul>
        <button className="product-button">Apply Now</button>
      </div>
      
      {/* Add more product sections as needed */}
    </div>
  );
}

export default ExploreProducts;
