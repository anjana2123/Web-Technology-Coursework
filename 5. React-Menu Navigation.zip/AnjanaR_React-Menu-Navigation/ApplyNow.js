// ApplyNow.js
import React from 'react';
import './ApplyNow.css'; // Import the CSS file for this component

function ApplyNow() {
  return (
    <div className="apply-now">
      <h2>Apply Now</h2>
      <p>Take the next step towards achieving your financial goals by applying for our products and services.</p>
      
      <div className="application">
        <h3>Apply for a Credit Card</h3>
        <p>Enjoy exclusive benefits and rewards by applying for an Axis Bank credit card.</p>
        <p>Features:</p>
        <ul>
          <li>Cashback offers and discounts</li>
          <li>Travel and dining privileges</li>
          <li>Secure and convenient payments</li>
        </ul>
        <button className="application-button">Apply Now</button>
      </div>
      
      <div className="application">
        <h3>Home Loan Application</h3>
        <p>Turn your dream of owning a home into reality with our easy home loan application process.</p>
        <p>Features:</p>
        <ul>
          <li>Flexible repayment options</li>
          <li>Attractive interest rates</li>
          <li>Assistance at every step of the application</li>
        </ul>
        <button className="application-button">Apply Now</button>
      </div>
      
      <div className="application">
        <h3>Open a Savings Account</h3>
        <p>Start saving for your future with our range of savings accounts tailored to your needs.</p>
        <p>Features:</p>
        <ul>
          <li>High interest rates</li>
          <li>No minimum balance requirement</li>
          <li>Convenient online account management</li>
        </ul>
        <button className="application-button">Apply Now</button>
      </div>
      
      {/* Add more application sections as needed */}
    </div>
  );
}

export default ApplyNow;
