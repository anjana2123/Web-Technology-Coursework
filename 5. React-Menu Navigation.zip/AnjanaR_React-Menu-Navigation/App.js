import React from 'react';
import {Routes, Route, Link } from 'react-router-dom';
import ExploreProducts from './ExploreProducts';
import GrabDeals from './GrabDeals';
import MakePayments from './MakePayments';
import BankSmart from './BankSmart';
import ApplyNow from './ApplyNow';
import Home from './Home';
import './App.css'; // Import the CSS file

function App() {
  return (
    <>
      <div className= "App">
        <nav>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/explore-products">Explore Products</Link></li>
            <li><Link to="/grab-deals">Grab Deals</Link></li>
            <li><Link to="/make-payments">Make Payments</Link></li>
            <li><Link to="/bank-smart">Bank Smart</Link></li>
            <li><Link to="/apply-now">Apply Now</Link></li>
          </ul>
        </nav>

        <div className="container">
          <Routes>
            {/* Other routes */}
            <Route exact path="/" element={<Home/>} /> 
            <Route path="/explore-products" element={<ExploreProducts/>} />
            <Route path="/grab-deals" element={<GrabDeals/>} />
            <Route path="/make-payments" element={<MakePayments/>} />
            <Route path="/bank-smart" element={<BankSmart/>} />
            <Route path="/apply-now" element={<ApplyNow/>} />
          </Routes>
        </div>
      </div>
    </>
  );
}

export default App;

/*
AI and DS Roles at Axis Bank:

Many financial institutions, including banks like Axis Bank, have been exploring the integration of 
AI (Artificial Intelligence) and DS (Data Science) in various aspects of their operations. 
This includes areas such as fraud detection, customer service chatbots, credit risk assessment, 
personalized marketing, and process automation. These technologies help streamline operations, enhance 
customer experiences, and make data-driven decisions.

Future Growth of Axis Bank:
The future of Axis Bank, like any other bank, largely depends on its ability to adapt and innovate in a 
rapidly changing technological landscape. As customers increasingly expect digital solutions and 
personalized experiences, integrating AI and DS could contribute to the bank's growth by providing more 
efficient and tailored services.

AI and DS Disruption in the Banking Sector:
AI and DS have the potential to disrupt the banking sector by revolutionizing various processes and 
customer interactions. Automation, predictive analytics, and real-time insights can lead to more effective 
risk management, fraud prevention, customer engagement, and operational efficiency.

Utilization of AI and DS by Axis Bank:
Axis Bank's successful utilization of AI and DS could lead to improved customer experiences, more accurate 
risk assessments, efficient fraud detection, and enhanced data-driven decision-making. AI-powered chatbots,
personalized recommendations, and automated processes could offer convenience and value to customers.

Interest in Making a Career at Axis Bank:
If Axis Bank continues to invest in AI and DS, there could be growing opportunities for professionals with 
expertise in these areas. Roles related to data analysis, machine learning, AI development, and data-driven
strategy could be in demand. As with any career choice, it's important to assess the alignment between your
skills, interests, and the company's goals.

*/