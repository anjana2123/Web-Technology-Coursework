// MakePayments.js
import React from 'react';
import './MakePayments.css'; // Import the CSS file for this component

function MakePayments() {
  return (
    <div className="make-payments">
      <h2>Make Payments</h2>
      <p>Easily manage your payments and transactions with our convenient banking solutions.</p>
      
      <div className="payment-option">
        <h3>Online Bill Payments</h3>
        <p>Pay your utility bills, credit card bills, and more online with just a few clicks.</p>
        <p>Features:</p>
        <ul>
          <li>Secure and encrypted payments</li>
          <li>Instant confirmation and receipt</li>
          <li>Save payee details for future use</li>
        </ul>
        <button className="payment-button">Pay Bills</button>
      </div>
      
      <div className="payment-option">
        <h3>Mobile Banking App</h3>
        <p>Download our mobile app to make payments on the go using your smartphone.</p>
        <p>Features:</p>
        <ul>
          <li>Transfer funds between accounts</li>
          <li>Scan and pay using QR codes</li>
          <li>View transaction history and account balances</li>
        </ul>
        <button className="payment-button">Download App</button>
      </div>
      
      <div className="payment-option">
        <h3>Contactless Payments</h3>
        <p>Use your Axis Bank debit or credit card for contactless payments at participating merchants.</p>
        <p>Features:</p>
        <ul>
          <li>Fast and secure transactions</li>
          <li>No need to enter a PIN for small purchases</li>
          <li>Accepted at a wide range of stores</li>
        </ul>
        <button className="payment-button">Learn More</button>
      </div>
      
      {/* Add more payment options as needed */}
    </div>
  );
}

export default MakePayments;
