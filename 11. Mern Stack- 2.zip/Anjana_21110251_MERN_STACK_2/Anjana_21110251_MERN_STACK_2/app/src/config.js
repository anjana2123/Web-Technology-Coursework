export const baseUrl = "http://localhost:5050";
