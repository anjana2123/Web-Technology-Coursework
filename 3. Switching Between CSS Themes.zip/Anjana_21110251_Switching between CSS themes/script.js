const lightThemeRadio = document.getElementById('lightTheme');
const darkThemeRadio = document.getElementById('darkTheme');
const personalThemeRadio = document.getElementById('personalTheme');
const themeLink = document.getElementById('theme-link');

lightThemeRadio.addEventListener('change', () => {
    if (lightThemeRadio.checked) {
        themeLink.setAttribute('href', 'light-theme.css');
    }
});

darkThemeRadio.addEventListener('change', () => {
    if (darkThemeRadio.checked) {
        themeLink.setAttribute('href', 'dark-theme.css');
    }
});

personalThemeRadio.addEventListener('change', () => {
    if (personalThemeRadio.checked) {
        themeLink.setAttribute('href', 'personalized-theme.css');
    }
});

